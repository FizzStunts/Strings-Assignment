// variable for the score
var count = 0;
// main function for the program
function palChecker()
{
    // variable for the submitted text
    var word1 = document.getElementById("palWord").value;
    // variable used in the "for" loop
    var i;
    // variable for the reversed version 
    var reversed = "";
    
    for (i= word1.length-1; i >=0; i--)
    {
        // sets the reversed version of the submitted text
        reversed += word1[i];
        // displays if the word is a palindrome and gives the score
        if (word1 == reversed)
        {
            document.getElementById("answer").innerHTML = "Palindrome Detected! Want to keep going";
            count++;
            document.getElementById("score").innerHTML = "Score: " + count;
        }
        // displays if the word isn't a palindrome
        else
        {
            document.getElementById("answer").innerHTML = "Not a Palindrome try again";
        }
    }
}
// this is to validate the login
function loginVar()
{
    // variables for the first and last name as well zip code
    var FstName = document.getElementById("fName").value;
    var SndName = document.getElementById("lName").value;
    var zipC = document.getElementById("zipCode").value;
    // puts the first and last name together
    var fulName = FstName + " " + SndName;
    // varifies loging
    if ((fulName == "Taren Vivlemore") || (fulName == "Jill Coddington"))
    {
        if ((zipC == "98638") || (zipC == "85283"))
        {
            // sends to the hidden reward page
            location.replace("Hidden Meme.html");
        }
        else
        {
            // sends to the hidden wrong info page
            location.replace("Wrong Meme.html");
        }
    }
    else if ((fulName != "Taren Vivlemore") || (fulName != "Jill Coddington"))
    {
        // sends to the hidden wrong info page
        location.replace("Wrong Meme.html");
    }
}
// this will return to the main page
function goBack()
{
    location.replace("Strings.html");
}